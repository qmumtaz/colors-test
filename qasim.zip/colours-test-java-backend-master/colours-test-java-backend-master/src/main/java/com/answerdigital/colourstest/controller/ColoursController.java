package com.answerdigital.colourstest.controller;

import com.answerdigital.colourstest.dto.ColourDto;
import com.answerdigital.colourstest.dto.PersonUpdateDTO;
import com.answerdigital.colourstest.model.Colour;
import com.answerdigital.colourstest.repository.ColoursRepository;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Colours")
public class ColoursController {

    @Autowired
    private ColoursRepository coloursRepository;

    @GetMapping
    public ResponseEntity<List<Colour>> getColours() {

        List<Colour> colours = coloursRepository.findAll();

        if (colours == null){
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(colours, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Colour> getColour(@PathVariable("id") Long id) {

        Colour colour = coloursRepository.getOne(id);

        if (colour == null){
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(colour, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Colour> getColour(@RequestBody ColourDto colourdto) {

        if (colourdto == null){
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        Colour colour = new Colour();
        colour.setName(colourdto.getName());

        Colour newColour = coloursRepository.save(colour);

        return new ResponseEntity<>(newColour, HttpStatus.OK);
    }
}
