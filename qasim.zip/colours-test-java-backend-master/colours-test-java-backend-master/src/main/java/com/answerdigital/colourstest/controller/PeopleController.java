package com.answerdigital.colourstest.controller;

import java.util.ArrayList;
import java.util.List;

import com.answerdigital.colourstest.dto.ColourDto;
import com.answerdigital.colourstest.model.Colour;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.answerdigital.colourstest.dto.PersonUpdateDTO;
import com.answerdigital.colourstest.model.Person;
import com.answerdigital.colourstest.repository.PeopleRepository;

@RestController
@RequestMapping("/People")
public class PeopleController {

    @Autowired
    private PeopleRepository peopleRespository;

    public PeopleController(PeopleRepository peopleRespository) {
        this.peopleRespository = peopleRespository;
    }

    @GetMapping
    public ResponseEntity<List<Person>> getPeople() {

        // Implement a JSON endpoint that returns the full list
        // of people from the PeopleRepository. If there are zero
        // people returned from PeopleRepository then an empty
        // JSON array should be returned.

        List<Person> people = peopleRespository.findAll();

        if (people == null || people.size() == 0) {

            return new ResponseEntity<>(new ArrayList<>(), HttpStatus.OK);
        }

        return new ResponseEntity<>(people, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Person> getPerson(@PathVariable("id") long id) {

        // Implement a JSON endpoint that returns a single person
        // from the PeopleRepository based on the id parameter.
        // If null is returned from the PeopleRepository with
        // the supplied id then a NotFound should be returned.

        Person person = peopleRespository.getOne(id);

        if(person == null){
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(person, HttpStatus.OK);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Person> updatePerson(@PathVariable("id") Long id,
                                               @RequestBody PersonUpdateDTO personUpdate) {

        // Implement an endpoint that recieves a JSON object to
        // update a person using the PeopleRepository based on
        // the id parameter. Once the person has been sucessfullly
        // updated, the person should be returned from the endpoint.
        // If null is returned from the PeopleRepository then a
        // NotFound should be returned.

        Person person = peopleRespository.getOne(id);

        if(person == null) {
            return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
        }

        person.setEnabled(personUpdate.isEnabled());
        person.setAuthorised(personUpdate.isAuthorised());
        person.setColours(personUpdate.getColours());

        Person savedPerson = peopleRespository.save(person);

        return new ResponseEntity<>(savedPerson, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Colour> getColour(@RequestBody ColourDto personUpdate) {

        if(personUpdate == null) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

        Person person = new Person();
        person.setFirstName(person.getFirstName());
        person.setLastName(person.getLastName());
        person.setEnabled(person.isEnabled());
        person.setAuthorised(person.isAuthorised());
        person.setColours(person.getColours());

        Person savedPerson = peopleRespository.save(person);

        return new ResponseEntity(savedPerson, HttpStatus.OK);
    }

}
