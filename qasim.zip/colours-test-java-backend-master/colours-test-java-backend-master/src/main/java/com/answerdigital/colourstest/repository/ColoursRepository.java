package com.answerdigital.colourstest.repository;

import com.answerdigital.colourstest.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.answerdigital.colourstest.model.Colour;

import java.util.List;

@Repository
public interface ColoursRepository extends JpaRepository<Colour, Long> {
    @Query("SELECT * FROM colour")
    List<Colour> findAll();

    @Query("SELECT * FROM colour where id =: id")
    List<Colour> findAllById(@Param("id") String id);

    @Query("SELECT * FROM colour where id =: id")
    Colour getOne(@Param("id") Long id);
}
