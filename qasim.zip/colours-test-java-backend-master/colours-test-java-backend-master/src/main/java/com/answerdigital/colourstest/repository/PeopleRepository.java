package com.answerdigital.colourstest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.answerdigital.colourstest.model.Person;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface PeopleRepository extends JpaRepository<Person, Long> {

    @Query("SELECT * FROM people")
    List<Person> findAll();

    @Query("SELECT * FROM people where id =: id")
    Person findAllById(@Param("id") Long id);

    @Query("SELECT * FROM people where id =: id")
    Person getOne(@Param("id") Long id);

}
